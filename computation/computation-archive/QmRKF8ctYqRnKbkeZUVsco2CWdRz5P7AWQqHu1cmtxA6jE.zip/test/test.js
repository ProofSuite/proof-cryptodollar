const chai = require('chai')
const should = chai.should()
var Computation = require('../computation');


describe("Average Price Test", async () => {

    describe("When rates are available and more than threshold", async () => {

        beforeEach(function() {
            Computation.init();
        });

        describe("", async () => {
            let inputRates1 = [864.09, 866.16, 867.30, 867.06, 863.82, 869.87, 894.50];
            it("should check avgPrice returns 866.38 for rates [864.09, 866.16, 867.3, 867.06, 863.82, 869.87, 894.50]", async () => {
                const avgPrice = await Computation.calculateAverage(inputRates1);
                const sampleMean = Computation.getSampleMean();
                const standardDeviation = Computation.getStandardDeviation();
                const validRates = Computation.getValidRates();
                sampleMean.should.equal(870.4);
                standardDeviation.should.equal(10.823944136342659);
                validRates.should.not.include(894.50);
                avgPrice.should.equal('866.38');
            });
        });

        describe("", async () => {
            let inputRates2 = [844.09, 866.16, 867.30, 867.06, 863.82, 869.87, 894.50];
            it("should check avgPrice returns 866.84 for rates [844.09, 866.16, 867.30, 867.06, 863.82, 869.87, 894.50]", async () => {
                const avgPrice = await Computation.calculateAverage(inputRates2);
                const sampleMean = Computation.getSampleMean();
                const standardDeviation = Computation.getStandardDeviation();
                const validRates = Computation.getValidRates();
                sampleMean.should.equal(867.5428571428572);
                standardDeviation.should.equal(14.70942862507549);
                validRates.should.not.include(844.09);
                validRates.should.not.include(894.50);
                avgPrice.should.equal('866.84');
            });
        });

        describe("", async () => {
            let inputRates3 = [844.09, 866.16, 867.30, 869.87];
            it("should check avgPrice returns 867.78 for rates [844.09, 866.16, 867.30, 869.87]", async () => {
                const avgPrice = await Computation.calculateAverage(inputRates3);
                const sampleMean = Computation.getSampleMean();
                const standardDeviation = Computation.getStandardDeviation();
                const validRates = Computation.getValidRates();
                sampleMean.should.equal(861.855);
                standardDeviation.should.equal(11.94454547760885);
                validRates.should.not.include(844.09);
                avgPrice.should.equal('867.78');
            });
        });

    });

    describe("When rates are available and less than threshold", async () => {

        beforeEach(function() {
            Computation.init();
        });

        describe("", async () => {
            let inputRates1 = [864.09];
            it("should check avgPrice returns 0 for rates [864.09]", async () => {
                const avgPrice = await Computation.calculateAverage(inputRates1);
                avgPrice.should.equal('0');
            });
        });

        describe("", async () => {
            let inputRates2 = [864.09, 866.16];
            it("should check avgPrice returns 0 for rates [864.09, 866.16]", async () => {
                const avgPrice = await Computation.calculateAverage(inputRates2);
                avgPrice.should.equal('0');
            });
        });

        describe("", async () => {
            let inputRates3 = [864.09, 866.16, 867.30];
            it("should check avgPrice returns 0 for rates [864.09, 866.16, 867.30]", async () => {
                const avgPrice = await Computation.calculateAverage(inputRates3);
                avgPrice.should.equal('0');
            });
        });
    });

    describe("When no rates are available", async () => {
        let inputRates = [];
        it("should check avgPrice returns 0 for rates []", async () => {
            const avgPrice = await Computation.calculateAverage(inputRates);
            avgPrice.should.equal('0');
        });

    });

});
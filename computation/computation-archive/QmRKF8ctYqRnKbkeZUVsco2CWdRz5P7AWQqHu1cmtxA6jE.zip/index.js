var Computation = require('./computation');

async function getAveragePrice() {
    try {
        const nonZeroRates = await Computation.getRates();
        const averagePrice = await Computation.calculateAverage(nonZeroRates);
        console.log(averagePrice);
    } catch (err) {
        console.log('0');
    }
}
getAveragePrice();
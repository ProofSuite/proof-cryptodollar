// This is the computation script used for testing the case
// where more than a certain of endpoints fail.
console.log('87537')   //exchange rate in cents (1ETH = 875.37USD)

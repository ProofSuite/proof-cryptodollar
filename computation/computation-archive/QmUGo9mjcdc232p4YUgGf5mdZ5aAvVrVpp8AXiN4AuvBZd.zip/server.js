// This is the computation script used for testing the case
// where more than a certain of endpoints fail.
// The script then returns 0
console.log('0')
